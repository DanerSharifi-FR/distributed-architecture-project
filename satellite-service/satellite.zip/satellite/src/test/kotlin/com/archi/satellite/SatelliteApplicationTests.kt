package com.archi.satellite

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SatelliteApplicationTests {

	@Test
	fun contextLoads() {
	}

}
