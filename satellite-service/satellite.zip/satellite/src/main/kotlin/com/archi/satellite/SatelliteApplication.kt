package com.archi.satellite

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SatelliteApplication

fun main(args: Array<String>) {
	runApplication<SatelliteApplication>(*args)
}
